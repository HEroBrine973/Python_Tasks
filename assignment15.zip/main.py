from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Firefox()
driver.get('http://www.amazon.in')

driver.maximize_window()

driver.find_element(By.ID, "twotabsearchtextbox").send_keys("iphone")

driver.find_element(By.ID, "nav-search-submit-button").click()

time.sleep(3)

list = driver.find_elements(By.XPATH, "//h2[@class='a-size-medium a-spacing-none a-color-base a-text-normal']")
# list = driver.find_elements(By.XPATH, "//div[@class='puisg-col-inner']")

print(str(len(list)) + ' products found')

for i in list:
    print(i.text)

driver.quit()