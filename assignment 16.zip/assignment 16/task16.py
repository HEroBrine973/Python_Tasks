from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# Setup Chrome options
options = Options()
# options.add_argument('--headless')  # Uncomment if headless is desired

# Initialize Chrome driver
driver = webdriver.Chrome(options=options)
wait = WebDriverWait(driver, 20)

try:
    driver.get('https://facebook.com')
    driver.maximize_window()

    # Login
    email_input = wait.until(EC.presence_of_element_located((By.ID, "email")))
    email_input.send_keys("1032230907@tcetmumbai.in")  # Replace with your email

    password_input = driver.find_element(By.ID, "pass")
    password_input.send_keys("NYYnyDyD7e9p3n-")  # Replace with your password

    driver.find_element(By.NAME, "login").click()

    # Wait until home is loaded
    post_box_trigger = wait.until(
        EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), \"What's on your mind\")]"))
    )
    post_box_trigger.click()

    # Wait for the text area and type the message
    text_area = wait.until(EC.visibility_of_element_located((By.XPATH, "//div[@role='textbox']")))
    message = "Hi There!"
    for char in message:
        text_area.send_keys(char)
        time.sleep(0.1)

    # Try to locate the Post button and click it
    post_button = wait.until(
        EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Post' or @aria-label='Share']"))
    )
    post_button.click()

    print("Post published successfully.")

except Exception as e:
    print(f"Error occurred: {e}")

finally:
    time.sleep(5)
    driver.quit()
