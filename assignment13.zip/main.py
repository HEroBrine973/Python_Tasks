import requests
from bs4 import BeautifulSoup

class PriceTracer:
    def __init__(self, url):
        self.url = url
        self.user_agent = {"User-Agent" : "Mozilla/5.0 (X11; Linux x86_64; rv:136.0) Gecko/20100101 Firefox/136.0"}
        self.response = requests.get(url = self.url, headers = self.user_agent).text
        self.soup = BeautifulSoup(self.response, "lxml")

    def product_title(self):
        title = self.soup.find("span", {"id" : "productTitle"})
        if title is not None:
            return title.text.strip()
        else:
            return "Tag Not Found"

    def product_price(self):
        price = self.soup.find("span", {"id" : "a-price-whole"})
        if price is not None:
            return price.text
        else:
            return "Tag Not Found"



device = PriceTracer(url = "https://www.amazon.in/Samsung-Smartphone-Titanium-Whitesilver-Included/dp/B0DSKL9MQ8/ref=sr_1_1_sspa?crid=2OT32V2J4I4R0&dib=eyJ2IjoiMSJ9.TSTIzp91Ds-y0dHIMXcN9yLw7ZVN0ypVfE1fdLDELUvW5D6qPSR4I6v3_OIMliOWbjNGm9LNwa4FnzXj2iBnkYSskQg214fVMRS8N-kOUI0eGFyMkHyi6CjN2GnslQKvJqPd7hXt30miE-DKnkIcgRyn3KLE6GWzGw3m4MnmdZ5DUyLYoV4lZbBWCzEU0HBfgjwRGU3aaRCuWcAZxMRaFFideOltZoMa-akkWM-19hY.vPAJ_QyrC5Edwax-aY_A0J6cGkdYMnt5t6zFFCCxzcY&dib_tag=se&keywords=samsung+s24+ultra+5g+mobile&nsdOptOutParam=true&qid=1746035145&sprefix=samsung%2Caps%2C394&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1")

print(device.product_title())
print(device.product_price())